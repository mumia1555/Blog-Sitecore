﻿using Sitecore.ContentSearch;
using Sitecore.ContentSearch.SearchTypes;
using System.Collections.Generic;
namespace SitecoreSolrIndexing.Models
{
    public class SearchModel : SearchResultItem
    {
        [IndexField("_name")]
        public virtual string ItemName { get; set; }
        [IndexField("title_t")]
        public virtual string Title { get; set; } // Custom field on my template
        [IndexField("blogid_t")]
        public virtual string BlogId { get; set; } // Custom field on my template
    }
    public class SearchResult
    {
        public string ItemName { get; set; }
        public string Title { get; set; }
        public string BlogId { get; set; }
    }
    /// <summary>
    /// Custom search result model for binding to front end
    /// </summary>
    public class SearchResults
    {
        public List<SearchResult> Results { get; set; }
    }
}
