﻿using Sitecore.ContentSearch;
using Sitecore.ContentSearch.Linq;
using Sitecore.ContentSearch.Linq.Utilities;
using SitecoreSolrIndexing.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;


namespace LucianHelix.Feature.Article.Controllers
{
    public class BlogController : Controller
    {
        // GET: Blog
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetList()
        {
            var setting = Sitecore.Context.Database.GetItem("{E7E182AC-1429-4B15-889C-72DCB2F88DDF}");
            string ids = setting.Fields["ArticleList"].Value;
            var idList = ids.Split('|');

            List<Sitecore.Data.Items.Item> items = new List<Sitecore.Data.Items.Item>();

            foreach (var id in idList)
            {
                var item = Sitecore.Context.Database.GetItem(id);
                
                items.Add(item);
            }

            return View("~/Views/Article/Blog.cshtml", items);
        }

        public ActionResult ReadOn(string id)
        {
            var item = Sitecore.Context.Database.GetItem(id);

            return View("~/Views/Article/Article.cshtml", item);
        }

        public ActionResult DoSearch(string searchText)
        {
            var myResults = new SearchResults
            {
                Results = new List<SearchResult>()
            };
            var searchIndex = ContentSearchManager.GetIndex("sitecore_web_index");
            var searchPredicate = GetSearchPredicate(searchText);
            using (var searchContext = searchIndex.CreateSearchContext())
            {

                var searchResults =
               searchContext.GetQueryable<SearchModel>().Where(searchPredicate);


                var fullResults = searchResults.GetResults();

                foreach (var hit in fullResults.Hits)
                {
                    myResults.Results.Add(new SearchResult
                    {
                        Title = hit.Document.Title,
                        BlogId = hit.Document.BlogId,
                        ItemName = hit.Document.ItemName,
                    });
                }
                return new JsonResult
                {
                    JsonRequestBehavior =
               JsonRequestBehavior.AllowGet,
                    Data = myResults
                };
            }
        }
        /// <summary>
        /// Search logic
        /// </summary>
        /// <param name="searchText">Search term</param>
        /// <returns>Search predicate object</returns>
        public static Expression<Func<SearchModel, bool>> GetSearchPredicate(string searchText)
        {
            var predicate = PredicateBuilder.True<SearchModel>();


            predicate = predicate.Or(x => x.Title.Contains(searchText));

            return predicate;
        }
    }
}